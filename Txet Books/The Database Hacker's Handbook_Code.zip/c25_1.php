<?php
// moviedatabase.php

// Connect to the Database
$conn = pg_connect("host=10.0.0.1 port=5432 dbname=movies user=postgres password=password!!"); 

// Retrieve title parameter from submitted URL 
$title = $_GET[title]; 

// Build query; note lack of input validation on $title
$query  = "SELECT title, description FROM movietable WHERE title LIKE �%$title%�;";

// Execute query and retrieve recordset
$myresult = pg_exec($conn, $query);

// Enumerate rows in recordset
  for ($lt = 0; $lt < pg_numrows($myresult); $lt++) 
  {
    $title = pg_result($myresult, $lt, 0);
    $description = pg_result($myresult, $lt, 1);
    $year = pg_result($myresult, $lt, 0);

    // Print results
    print("<br><br>\n");
    print("Title: $title <br/>\n");
    print("Description: $description <br/>\n");
    print("Year: $year <br/>\n");
  }

// If no records were matched, display a message 
if (pg_numrows($myresult) == 0) print("Sorry no results found. <br>\n");
?>
