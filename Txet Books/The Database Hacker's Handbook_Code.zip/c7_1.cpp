#include <stdio.h>
#include <windows.h>
#include <winsock.h>

int QueryDB2Server(void);
int StartWinsock(void);


struct sockaddr_in s_sa;
struct hostent *he;
unsigned int addr;
int DB2Port=523;
char host[260]="";
char request[]="DB2GETADDR\x00SQL08010";


int main(int argc, char *argv[])
{
     unsigned int ErrorLevel=0;

     if(argc != 2)
     {
          printf("\n\tQueryDB2\n\n");
          printf("\tSends a UDP packet to port 523 to see if\n");
          printf("\tthe remote server is running DB2.\n\n");
          printf("\tUsage: C:\\>%s target\n\n\t",argv[0]);
          printf("David Litchfield\n\t(david@ngssoftware.com)\n\t6th September 2003\n\n");
          return 0;
     }
     strncpy(host,argv[1],250);

     if(StartWinsock() == 0)
          return printf("Error starting Winsock.\n");
     
     QueryDB2Server();
     WSACleanup();
          
     return 0;

}          


int StartWinsock()
{
     int err=0;
     WORD wVersionRequested;
     WSADATA wsaData;

     wVersionRequested = MAKEWORD(2,0);
     err = WSAStartup(wVersionRequested, &wsaData);
     if (err != 0)
          return 0;

     if (LOBYTE(wsaData.wVersion) !=2 || HIBYTE(wsaData.wVersion) != 0 )
       {
          WSACleanup();
          return 0;
     }

     s_sa.sin_addr.s_addr=INADDR_ANY;
     s_sa.sin_family=AF_INET;
     s_sa.sin_port=htons((unsigned short)DB2Port);
          
     if (isalpha(host[0]))
       {
          he = gethostbyname(host);
          if(he == NULL)
          {
               printf("Couldn't resolve %s\n",host);
               WSACleanup();
               return 0;
          }
          memcpy(&s_sa.sin_addr,he->h_addr,he->h_length);
          
     }
     else
     {
          addr = inet_addr(host);
          memcpy(&s_sa.sin_addr,&addr,4);
     }
     
     return 1;
}



int QueryDB2Server(void)
{
     char resp[600]="";
     int rcv=0,count=0;
     SOCKET cli_sock;


     cli_sock=socket(AF_INET,SOCK_DGRAM,0);
     if(cli_sock==INVALID_SOCKET)
     {
          printf("socket error %d.\n",GetLastError());
          return 0;
     }


         if(connect(cli_sock,(LPSOCKADDR)&s_sa,sizeof(s_sa))==SOCKET_ERROR)
     {
          closesocket(cli_sock);
          printf("Connect error %d.\n",GetLastError());
          return 0;
     }
          
     if(send(cli_sock, request, 20, 0) !=20)
     {
          closesocket(cli_sock);
          printf("Send error %d\n",GetLastError());
          return 0;
     }
     rcv = recv(cli_sock,resp,596,0);
     if(rcv > 1)
     {
          while(count < rcv)
          {
               if(resp[count]==0x00)
                    resp[count]=0x20;
               count++;
          }
          printf("\n%s",resp);               
     }
     else
          printf("Server did not respond.\n");


     return 0;
}
