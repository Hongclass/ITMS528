#include <stdio.h>
#include <windows.h>
#include <winsock.h>
int SendTNSPacket(void);
int StartWinsock(void);
int packet_length(char *);
int PrintResp(unsigned char *p, int l);
struct sockaddr_in c_sa;
struct sockaddr_in s_sa;
struct hostent *he;
SOCKET sock;
unsigned int addr;
char data[32000]="";
int ListenerPort=1521;
char host[260]="";
int prt = 40025;
int PKT_LEN = 0x98;
int two_packets=0;
unsigned char TNSPacket[200]=
"\x00\x3A"		// Packet length
"\x00\x00"		// Checksum
"\x01"			// Type - connect
"\x00"			// Flags
"\x00\x00"		// Header checksum
"\x01\x39"		// Version
"\x01\x2C"		// Compat version
"\x00\x00"		// Global service options
"\x08\x00"		// PDU
"\x7F\xFF"		// TDU
"\x86\x0E"		// Protocol Characteristics
"\x00\x00"		// 
"\x01\x00"		// Byte order
"\x00\x85"		// Datalength
"\x00\x3A"		// Offset
"\x00\x00\x07\xF8"	// Max recv
"\x0C\x0C"		// ANO
"\x00\x00"
"\x00\x00\x00\x00"
"\x00\x00\x00\x00"
"\x0A\x4C\x00\x00"
"\x00\x03\x00\x00"
"\x00\x00\x00\x00"
"\x00\x00";
unsigned char TNSPacket2[200]=
"\x00\x00"	// Packet Length
"\x00\x00"	// Checksum
"\x06"		// Type - data
"\x00"		// Flags
"\x00\x00"	// Header Checksum
"\x00\x00";

int main(int argc, char *argv[])
{
	unsigned int ErrorLevel=0,len=0,c =0;
	int count = 0;
	if(argc < 3)
		return printf("%s host string\n",argv[0]);
	strncpy(host,argv[1],256);
	strncpy(data,argv[2],31996);
	if(argc == 4)
		ListenerPort = atoi(argv[3]);

	if(StartWinsock()==0)
	{
		printf("Error starting Winsock.\n");
		return 0;
	}
	
	PKT_LEN = packet_length(data);
	SendTNSPacket();
	return 0;
}		

int packet_length(char *datain)
{
	int dl=0;
	int hl=0x3A;
	int tl=0;
	int e = 0;
	int f =0;
	dl = strlen(datain);
	printf("dl = %d and total = %d\n",dl,dl+hl);
	
	if(dl == 255 || dl > 255)
	{
		e = dl % 256;
		e = dl - e;
		e = e / 256;
		TNSPacket[24]=e;
		f = dl % 256;
		TNSPacket[25]=f;
		dl = dl + 10;
		e = dl % 256;
		e = dl - e;
		e = e / 256;
		TNSPacket2[0]=e;
		f = dl % 256;
		TNSPacket2[1]=f;
		two_packets = 1;
	}
	else
	{
		TNSPacket[25]=dl;
		TNSPacket[1]=dl+0x3A;
	}
		
	return dl+hl;
}

int StartWinsock()
{
	int err=0;
	WORD wVersionRequested;
	WSADATA wsaData;
	wVersionRequested = MAKEWORD( 2, 0 );
	err = WSAStartup( wVersionRequested, &wsaData );
	if ( err != 0 )
		return 0;
		
	if ( LOBYTE( wsaData.wVersion ) != 2 || HIBYTE( wsaData.wVersion ) != 0 )
  	{
		WSACleanup( );
		return 0;
	}
	if (isalpha(host[0]))
		he = gethostbyname(host);
	else
	{
		addr = inet_addr(host);
		he = gethostbyaddr((char *)&addr,4,AF_INET);
	}
	if (he == NULL)
		return 0;
	s_sa.sin_addr.s_addr=INADDR_ANY;
	s_sa.sin_family=AF_INET;
	memcpy(&s_sa.sin_addr,he->h_addr,he->h_length);
	return 1;
}

int SendTNSPacket(void)
{
	SOCKET c_sock;
	unsigned char resp[10000]="";
	int snd=0,rcv=0,count=0, var=0;
	unsigned int ttlbytes=0;
	unsigned int to=2000;
	struct sockaddr_in        srv_addr,cli_addr;
	LPSERVENT            srv_info;
	LPHOSTENT            host_info;
	SOCKET            cli_sock;

	cli_sock=socket(AF_INET,SOCK_STREAM,0);
	if (cli_sock==INVALID_SOCKET)
		return printf(" sock error");
    		
	cli_addr.sin_family=AF_INET;
	cli_addr.sin_addr.s_addr=INADDR_ANY;        
	cli_addr.sin_port=htons((unsigned short)prt);
	if (bind(cli_sock,(LPSOCKADDR)&cli_addr,sizeof(cli_addr))==SOCKET_ERROR)
	{
		closesocket(cli_sock);
    		return printf("bind error");
    	}
	s_sa.sin_port=htons((unsigned short)ListenerPort);
	if (connect(cli_sock,(LPSOCKADDR)&s_sa,sizeof(s_sa))==SOCKET_ERROR)
	{
		printf("Connect error %d",GetLastError());
		return closesocket(cli_sock);
	}
	snd=send(cli_sock, TNSPacket , 0x3A , 0);
	if(two_packets == 1)
		snd=send(cli_sock, TNSPacket2 , 10 , 0);
    	snd=send(cli_sock, data , strlen(data) , 0);
	rcv = recv(cli_sock,resp,9996,0);
	if(rcv != SOCKET_ERROR)
		PrintResp(resp,rcv);
		
	closesocket(cli_sock);
	return 0;
}
int PrintResp(unsigned char *p, int l)
{
	int c = 0;
	int d = 0;
	while(c < l)
	{
		printf("%.2X ",p[c]);
		c ++;
		if(c % 16 == 0)
		{
			d = c - 16;
			printf("\t");
			while(d < c)
			{	
				if(p[d] == 0x0A || p[d] == 0x0D)
					printf(" ");
				else
					printf("%c",p[d]);
				d++;
			}
			printf("\n");
			d = 0;
		}
	}
	d = c - 16;
	printf("\t");
	while(d < c)
	{	
		if(p[d] == 0x0A || p[d] == 0x0D)
			printf(" ");
		else
			printf("%c",p[d]);
		d++;
	}
	printf("\n");
	d = 0;
	
	return 0;
}
