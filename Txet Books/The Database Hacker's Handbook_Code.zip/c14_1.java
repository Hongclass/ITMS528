import java.io.*;
import java.lang.*;
import java.net.*;
import java.sql.*;
import javax.servlet.*;
import javax.servlet.http.*;
import com.sybase.jdbc2.jdbc.*;
public class BookQuery extends HttpServlet 
{
    public void init(ServletConfig config) throws ServletException 
    {
        super.init(config);
    }
    
    public void destroy(){}
    
    protected void processRequest(
HttpServletRequest request, 
HttpServletResponse response)
    throws ServletException, IOException
    {
        PrintWriter out = response.getWriter();
        try
        {
            response.setContentType("text/html");
            out.println("<html><head><title>Book Title Search Results</title></head>");
            out.println("<body><h1>Search results</h1>");
            Class.forName("com.sybase.jdbc2.jdbc.SybDriver");
            Connection con = DriverManager.getConnection("jdbc:sybase:Tds:sybtest:5000","sa", "sapassword");
            Statement stmt = con.createStatement();
            String search = request.getParameter("search");
            ResultSet rs = stmt.executeQuery("select * from pubs2..titles where UPPER(title) like UPPER('%" + search + "%')");
            int numberOfColumns = rs.getMetaData().getColumnCount();            
            rs.next();
            out.println("<TABLE border=1>");
            while( !rs.isAfterLast())
            {
                    out.print("<TR>");
                    for( int i = 1; i <= numberOfColumns; i++ )
                    {
                        out.print("<TD>");
                        out.print(rs.getString(i));
                        out.print("</TD>");
                    }
                    out.print("</TR>");
                    rs.next();
            }
            rs.close();
            out.println("</TABLE>");
            out.println("</body>");
            out.println("</html>");
        }
        catch( SQLException e )
        {
            while( e != null )
            {
                out.println(e);   
                e = e.getNextException();
            }
        }
        catch( Exception e )
        {
                out.println("Exception:" + e);   
        }
    }
    
    protected void doGet(HttpServletRequest request, HttpServletResponse response)
    throws ServletException, IOException
    {
        processRequest(request, response);
    }
    
    protected void doPost(HttpServletRequest request, HttpServletResponse response)
    throws ServletException, IOException 
    {
        processRequest(request, response);
    }
    
    public String getServletInfo() 
    {
        return "SQL Injection Servlet Sample";
    }
    
}
