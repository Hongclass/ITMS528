#include <stdio.h>
#include <windows.h>
#include <winsock.h>
#define PHEADER 2
#define HSIZE	8
#define SQLEXEC 8
#define PASS_START 2
#define VERSION 12
#define RDS 13
#define DB_START 2
#define IEEE_START 2
#define IEEE 6
#define DP_START 2
#define DBM_START 2
#define DBMONEY 3
#define CL_START 14
#define CL 13
#define CPC_START 17
#define CPC 2
#define DBL_START 10
#define DBL 10
int MakeRequest();
int StartWinsock(void);
int CreateConnectPacket();
int Base64Encode(char *str);
int IfxPort = 1516;
int len = 0;
struct sockaddr_in s_sa;
struct hostent *he;
unsigned int addr;
unsigned char host[260]="";
unsigned char *Base64Buffer = NULL;
unsigned char username[4260]="";
unsigned char password[4260]="";
unsigned char database[4260]="";
unsigned char dbaspath[4260]="";
unsigned char crud[]=
"\x3a\x41\x47\x30\x41\x41\x41\x41\x39\x62\x32\x77\x41\x41\x41\x41"
"\x41\x41\x41\x41\x41\x41\x41\x41\x39\x63\x32\x39\x6a\x64\x47\x4e"
"\x77\x41\x41\x41\x41\x41\x41\x41\x42\x41\x41\x41\x42\x4d\x51\x41"
"\x41\x41\x41\x41\x41\x41\x41\x41\x41\x63\x33\x46\x73\x5a\x58\x68"
"\x6c\x59\x77\x41\x41\x41\x41\x41\x41\x41\x41\x56\x7a\x63\x57\x78"
"\x70\x41\x41\x41\x43\x41\x41\x41\x41\x41\x77\x41\x4b\x62\x32\x78"
"\x66\x61\x47\x56\x6a\x64\x47\x39\x79\x41\x41\x42\x72\x41\x41\x41"
"\x41\x41\x41\x41\x41\x44\x6d\x67\x41\x41\x41\x41\x41\x41\x41\x64"
"\x54\x53\x56\x4a\x4a\x56\x56\x4d\x41\x41\x41\x64\x54\x53\x56\x4a"
"\x4a\x56\x56\x4d\x41\x41\x43\x42\x44\x4f\x6c\x78\x45\x62\x32\x4e"
"\x31\x62\x57\x56\x75\x64\x48\x4d\x67\x59\x57\x35\x6b\x49\x46\x4e"
"\x6c\x64\x48\x52\x70\x62\x6d\x64\x7a\x58\x45\x52\x42\x56\x6b\x6c"
"\x45\x41\x41\x42\x30\x41\x41\x67\x41\x41\x41\x54\x53\x41\x41\x41"
"\x41\x41\x41\x42\x5f\x00";
unsigned char header[12]="\x01\x7A\x01\x3D\x00\x00";
char *ConnectPacket = NULL;

int CreateConnectPacket()
{
      unsigned short x = 0;
      len = 0;
      len = PHEADER + HSIZE + SQLEXEC;
      len = len + PASS_START + VERSION + RDS;
      len = len + DB_START + IEEE_START + IEEE;
      len = len + DP_START + DBM_START + DBMONEY;
      len = len + CL_START + CL + CPC_START;
      len = len + CPC + DBL_START + DBL;
      len = len + strlen(username) + 1;
      len = len + strlen(password) + 1;
      len = len + strlen(database) + 1;
      len = len + strlen(dbaspath) + 1;
      len = len + sizeof(crud);
      len ++;
      ConnectPacket = (char *)malloc(len);
      if(!ConnectPacket)
            return 0;
      memset(ConnectPacket,0,len);
      
      strcpy(ConnectPacket,"\x73\x71");                        // HEADER
      strcat(ConnectPacket,"\x41\x59\x49\x42\x50\x51\x41\x41");      // Size
      strcat(ConnectPacket,"\x73\x71\x6c\x65\x78\x65\x63\x20");      // sqlexec
      strcat(ConnectPacket,username);                              // username
      strcat(ConnectPacket,"\x20");                              // space
      strcat(ConnectPacket,"\x2d\x70");                        // password_start
      strcat(ConnectPacket,password);                              // password *
      strcat(ConnectPacket,"\x20");                              // space
      strcat(ConnectPacket,"\x39\x2e\x32\x32\x2e\x54\x43\x33\x20\x20\x20"); // version
      strcat(ConnectPacket,"\x52\x44\x53\x23\x4e\x30\x30\x30\x30\x30\x30\x20"); // RDS
      strcat(ConnectPacket,"\x2d\x64");                        // database_start
      strcat(ConnectPacket,database);                         // database *
      strcat(ConnectPacket,"\x20");                              // space
      strcat(ConnectPacket,"\x2d\x66");                        // ieee_start
      strcat(ConnectPacket,"\x49\x45\x45\x45\x49\x20");            // IEEE
      strcat(ConnectPacket,"\x44\x42\x50\x41\x54\x48\x3d\x2f\x2f");      // dbpath_start 
      strcat(ConnectPacket,dbaspath);                              // dbpath *
      strcat(ConnectPacket,"\x20");                              // space
      strcat(ConnectPacket,"\x44\x42\x4d\x4f\x4e\x45\x59\x3d");      // dbmoney_start
      strcat(ConnectPacket,"\x24\x2e\x20");                        // dbmoney                  
      strcat(ConnectPacket,"\x43\x4c\x49\x45\x4e\x54\x5f\x4c\x4f\x43\x41\x4c\x45\x3d"); // client_locale_start
      strcat(ConnectPacket,"\x65\x6e\x5f\x55\x53\x2e\x43\x50\x31\x32\x35\x32\x20"); // client_locale
      strcat(ConnectPacket,"\x43\x4c\x4e\x54\x5f\x50\x41\x4d\x5f\x43\x41\x50\x41\x42\x4c\x45\x3d"); // client_pam_capable_start
      strcat(ConnectPacket,"\x31\x20");                        // cli-ent_pam_capable
      strcat(ConnectPacket,"\x44\x42\x5f\x4c\x4f\x43\x41\x4c\x45\x3d"); // db_locale_start
      strcat(ConnectPacket,"\x65\x6e\x5f\x55\x53\x2e\x38\x31\x39\x20"); // db_locale
      strcat(ConnectPacket,crud);

      x = (unsigned short) strlen(ConnectPacket);
      x = x >> 8;
      header[0]=x;
      x = (unsigned short) strlen(ConnectPacket);
      x = x - 3;
      x = x << 8;
      x = x >> 8;
      header[1]=x;
      Base64Encode(header);
      if(!Base64Buffer)
            return 0;
      memmove(&ConnectPacket[2],Base64Buffer,8);
      return 1;
}

int main(int argc, char *argv[])
{
      unsigned int ErrorLevel=0;
      int count = 0;
      char buffer[100000]="";
      if(argc != 7)
      {
            printf("Informix Tester.\n");
            printf("C:\\>%s host port username password database dbpath\n",argv[0]);
            return 0;
      }

      printf("Here");
      strncpy(host,argv[1],256);
      strncpy(username,argv[3],4256);
      strncpy(password,argv[4],4256);
      strncpy(database,argv[5],4256);
      strncpy(dbaspath,argv[6],4256);
      IfxPort = atoi(argv[2]);
      if(CreateConnectPacket()==0)
            return printf("Error building Connect packet.\n");
      printf("\n%s\n\n\n",ConnectPacket);
      ErrorLevel = StartWinsock();
      if(ErrorLevel==0)
            return printf("Error starting Winsock.\n");
      MakeRequest1();
      WSACleanup();
      if(Base64Buffer)
            free(Base64Buffer);
            
      return 0;
}            

int StartWinsock()
{
      int err=0;
      WORD wVersionRequested;
      WSADATA wsaData;
      wVersionRequested = MAKEWORD( 2, 0 );
      err = WSAStartup( wVersionRequested, &wsaData );
      if ( err != 0 )
            return 0;
      if ( LOBYTE( wsaData.wVersion ) != 2 || HIBYTE( wsaData.wVersion ) != 0 )
        {
            WSACleanup();
            return 0;
      }
      if (isalpha(host[0]))
        {
            he = gethostbyname(host);
            s_sa.sin_addr.s_addr=INADDR_ANY;
            s_sa.sin_family=AF_INET;
            memcpy(&s_sa.sin_addr,he->h_addr,he->h_length);
      }
      else
      {
            addr = inet_addr(host);
            s_sa.sin_addr.s_addr=INADDR_ANY;
            s_sa.sin_family=AF_INET;
            memcpy(&s_sa.sin_addr,&addr,4);
            he = (struct hostent *)1;
      }
      if (he == NULL)
        {
            WSACleanup();
            return 0;
        }
      return 1;
}


int MakeRequest1()
{
      char resp[600]="";
      int snd=0,rcv=0,count=0, var=0;
      unsigned int ttlbytes=0;
      unsigned int to=10000;
      struct sockaddr_in cli_addr;
      SOCKET cli_sock;
      char *ptr = NULL;
      char t[20]="";
      char status[4]="";

      cli_sock=socket(AF_INET,SOCK_STREAM,0);
      if (cli_sock==INVALID_SOCKET)
            return printf("socket error.\n");

      setsockopt(cli_sock,SOL_SOCKET,SO_RCVTIMEO,(char *)&to,sizeof(unsigned int));
          s_sa.sin_port=htons((unsigned short)1526);
      if (connect(cli_sock,(LPSOCKADDR)&s_sa,sizeof(s_sa))==SOCKET_ERROR)
      {
            closesocket(cli_sock);
            printf("Connect error.\n");
            ExitProcess(0);
      }
      

      send(cli_sock,ConnectPacket,strlen(ConnectPacket)+1,0);
      rcv = recv(cli_sock,resp,596,0);
      if(rcv == SOCKET_ERROR)
      {
            printf("recv error.\n");
            goto endfunc;
      }
      printf("Recv: %d bytes [%x]\n",rcv,resp[0]);
      count = 0;
      while(count < rcv)
      {
            if(resp[count]==0x00 || resp[count] < 0x20 || resp[count] > 0x7F)
                  resp[count]=0x20;
            count ++;
      }
      printf("%s\n\n\n",resp);
endfunc:
      ZeroMemory(resp,600);
      closesocket(cli_sock);
      return 0;
}
int Base64Encode(char *str)
{
      unsigned int length = 0, cnt = 0, res = 0, count = 0, l = 0;
      unsigned char A = 0;
      unsigned char B = 0;
      unsigned char C = 0;
      unsigned char D = 0;
      unsigned char T = 0;
      unsigned char tmp[8]="";
      unsigned char *ptr = NULL, *x = NULL;
            
      length = strlen(str);
      if(length > 0xFFFFFF00)
      {
            printf("size error.\n");
            return 0;
      }
      res = length % 3;
      if(res)
      {
            res = length - res;
            res = length / 3;
            res ++;
      }
      else
            res = length / 3;
      
      l = res;
      
      res = res * 4;

      if(res < length)
      {
            printf("size error");
            return 0;
      }

      Base64Buffer = (unsigned char *) malloc(res+1);
      if(!Base64Buffer)
      {
            printf("malloc error");
            return 0;
      }
      memset(Base64Buffer,0,res+1);

      ptr = (unsigned char *) malloc(length+16);
      if(!ptr)
      {
            free(Base64Buffer);
            Base64Buffer = 0;
            printf("malloc error.\n");
            return 0;
      }
      
      memset(ptr,0,length+16);
      x = ptr;
      strcpy(ptr,str);
      while(count < l)
      {
            A = ptr[0] >> 2;
            B = ptr[0] << 6;
            B = B >> 2;
            T = ptr[1] >> 4;
            B = B + T;
            C = ptr[1] << 4;
            C = C >> 2;
            T = ptr[2] >> 6;
            C = C + T;
            D = ptr[2] << 2;
            D = D >> 2;
            tmp[0] = A;
            tmp[1] = B;
            tmp[2] = C;
            tmp[3] = D;
            while(cnt < 4)
            {
                  if(tmp[cnt] < 26)
                        tmp[cnt] = tmp[cnt] + 0x41;
                  else if(tmp[cnt] < 52)
                        tmp[cnt] = tmp[cnt] + 0x47;
                  else if(tmp[cnt] < 62)
                        tmp[cnt] = tmp[cnt] - 4;
                  else if(tmp[cnt] == 62)
                        tmp[cnt] = 0x2B;
                  else if(tmp[cnt] == 63)
                        tmp[cnt] = 0x2F;
                  else
                        {
                              free(x);
                              free(Base64Buffer);
                              Base64Buffer = NULL;
                              return 0;
                        }
                  cnt ++;
            }
            cnt = 0;
            ptr = ptr + 3;
            count ++;
            strcat(Base64Buffer,tmp);
      }

      free(x);
      return 1;

}
