create procedure RemoteQuery( 	@host varchar(1000), 
            @port integer, 
            @user varchar(30), 
            @password varchar(30), 
            @query varchar(8000) ) as
begin
declare @s java.net.Socket
      declare @is java.io.InputStream
      declare @os java.io.OutputStream
      declare @banner varchar(2000)
      declare @p varbinary(2048)
      declare @i integer
      set @s = new java.net.Socket( @host, @port )
      set @is = @s>>getInputStream()
      set @os = @s>>getOutputStream()
      set @p = 0x0200020000000000
      set @p = @p + 'XXXXXXX' + 0x000000
      set @p = @p + 0x0000000000000000000000000000000000000000
      set @p = @p + 0x07
      set @p = @p + @user + replicate(0x00, 30-len(@user))
      set @p = @p + convert(varbinary(1), len(@user))
      set @p = @p + @password + replicate(0x00, 30-len(@password))
      set @p = @p + convert(varbinary(1), len(@password))
      set @p = @p + 0x3131353200000000000000000000000000000000
      set @p = @p + 0x00000000000000000000040301060a0901
      set @p = @p + 0x01000000000000000000 + "SQL_Advantage"
      set @p = @p + 0x0000000000000000000000000000000000
      set @p = @p + 0x0d + "XXXXXXX" + 0x000000
      set @p = @p + 0x0000000000000000000000000000000000000000
      set @p = @p + 0x0700
      set @p = @p + convert(varbinary(1), len(@password))
      set @p = @p + @password + replicate(0x00, 30-len(@password))
      set @p = @p + replicate( 0x00, 223 )
      set @p = @p + 0x0c05000000 + "CT-Library"
      set @p = @p + 0x0a05000000000d11
      set @p = @p + 0x00 + "s_english"
      set @p = @p + 0x0000000000000000000000000000
      set @os = @os>>"write"(@p)      
      set @os = @os>>flush()
      set @p = 0x02010063000000000000000000000000
      set @p = @p + 0x0000000000000000000000000069736f
      set @p = @p + 0x5f310000000000000000000000000000
      set @p = @p + 0x00000000000000000000000500353132
      set @p = @p + 0x0000000300000000e21800010a018608
      set @p = @p + 0x336d7ffffffffe020a00000000000a68
      set @p = @p + 0x000000
      set @os = @os>>"write"(@p)      
      set @os = @os>>flush()
      set @i = java.lang.Thread.currentThread()>>sleep( 1000 )
      while( @is>>available() > 0 )
      begin
            select @banner = @banner + char(@is>>"read"())
      end
      if( substring(@banner, 9, 1) = 0xad ) and (substring(@banner, 12, 1) = 0x06)
            return -- login failed
      set @p = 0x0f01
      set @p = @p + convert( varbinary(1), (len(@query)+14)/256 )      
      set @p = @p + convert( varbinary(1), (len(@query)+14)%256 )
      set @p = @p + 0x0000000021
      set @p = @p + convert( varbinary(1), (len(@query)+1)%256 )
      set @p = @p + convert( varbinary(1), (len(@query)+1)/256 )
      set @p = @p + 0x000000
      set @p = @p + @query      
      set @os = @os>>"write"(@p)      
      set @os = @os>>flush()
      set @i = java.lang.Thread.currentThread()>>sleep( 1000 )
      select @banner = 0x20
      while( @is>>available() > 0 )
      begin
            set @i = @is>>"read"()
            if( @i >= 0x20 ) and ( @i <= 0x7f )
                  select @banner = @banner + char(@i)
      end
      select @banner
      set @s = @s>>"close"()
end
