#include <stdio.h>
int main(int argc, char *argv[])
{
     unsigned int index = 0, temp, is_null = 0, input_length;
     char input[256], output[256], hexbyte[2];
     if (argc != 2)
          {
          printf("\nUsage: %s [obfuscated password]\n\ne.g. %s 92A5F3A593A582A596A5E2A597A5\n", argv[0], argv[0]);
          return 0;
          }
     strncpy(input, argv[1], 256);
     input_length = strlen(input);
     printf("\nThe password is: ");
while ((index < input_length) && (index < 256))
     {     
     hexbyte[0] = input[index];
     hexbyte[1] = input[index + 1];
     hexbyte[2] = 0;
     // convert hex string to an integer
     temp = HexToInt(hexbyte);
     // XOR with A5
     temp = temp ^ 0xA5;
     // swap nibbles
     temp = ((temp >> 4 ) | (temp << 4));     
 
     // output every other password letter
     if (!is_null)
          printf("%c", temp);     
     index += 2;
     
     // flip is_null to opposite value
     is_null = (is_null) ? 0 : 1;
     
} // end while
     printf("\n");
return 0;
}

// convert a two-byte hexadecimal character string to an integer value
int HexToInt(char *HexByte) 
  {
  int n;        
  int IntValue = 0;
  int digits[2];
  // return if two characters were not submitted
  if (strlen(HexByte) != 2)
     return 0;
  // set corresponding integer values for both chars
  for (n = 0; n <= 1; n++)
     {
     if (HexByte[n] >= '0' && HexByte[n] <= '9' ) 
          digits[n] = HexByte[n] & 0x0f;
     else if ((HexByte[n] >='a' && HexByte[n] <= 'f') || (HexByte[n] >='A' && HexByte[n] <= 'F'))
             digits[n] = (HexByte[n] & 0x0f) + 9;
     }
  // first digit designates a value 16 times more than second
  IntValue = (digits[0] * 16) + digits[1];
  return IntValue;
}
