#include <stdlib.h>
#include <postgres.h>
#include <fmgr.h>

PG_FUNCTION_INFO_V1(pgsystem);

Datum pgsystem(PG_FUNCTION_ARGS)
{
 text *commandText = PG_GETARG_TEXT_P(0);
 int32 commandLen  = VARSIZE(commandText) - VARHDRSZ;
 char *command     = (char *) palloc(commandLen + 1);
 int32 result = 0;

 memcpy(command, VARDATA(commandText), commandLen);
 command[commandLen] = '\0';
 
 // For debugging purposes, log command
 // Attacker would not want to log this!!
 //  elog(ERROR, "About to execute %s\n", command);

 result = system(command);
 pfree(command);

 PG_RETURN_INT32(result);
}
