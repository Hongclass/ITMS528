#include <stdio.h>


unsigned char trans(unsigned char ch);
unsigned char ebdic[]=
"\x40\x4F\x40\x7B\x5b\x6c\x50\x7d\x4d\x5d\x5c\x4e\x6b\x60\x4b\x61"
"\xf0\xf1\xf2\xf3\xf4\xf5\xf6\xf7\xf8\xf9\x7a\x5e\x4c\x7e\x6e\x6f"
"\x7c\xc1\xc2\xc3\xc4\xc5\xc6\xc7\xc8\xc9\xd1\xd2\xd3\xd4\xd5\xd6"
"\xd7\xd8\xd9\xe2\xe3\xe4\xe5\xe6\xe7\xe8\xe9\x4A\xe0\x5a\x5f\x6d"
"\x79\x81\x82\x83\x84\x85\x86\x87\x88\x89\x91\x92\x93\x94\x95\x96"
"\x97\x98\x99\xa2\xa3\xa4\xa5\xa6\xa7\xa8\xa9\xc0\x6a\xd0\x00";


int main()
{
     int len = 0,cnt=0;
     unsigned char password[]="\x98\xa4\x89\x82\xf1\x85";
     unsigned char username[]="\x99\x96\x96\xa3";

     while(cnt < 6)
     {
          printf("%c",trans(password[cnt]));
          cnt ++;
     }
     cnt = 0;
     printf("\n");
     while(cnt < 4)
     {
          printf("%c",trans(username[cnt]));
          cnt ++;
     }
     return 0;
     

}

unsigned char trans(unsigned char ch)
{
     unsigned char cnt=0;

     while(cnt < 95)
     {
          if(ch == ebdic[cnt])
               return cnt+0x20;
          cnt ++;
     }
     return 0x20;
}
