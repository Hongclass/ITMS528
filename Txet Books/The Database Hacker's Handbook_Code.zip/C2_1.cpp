/************************************
/ Compile from a command line
/
/ C:\>cl /TC oraver.c /link wsock32.lib
/
*/
#include <stdio.h>
#include <windows.h>
#include <winsock.h>

int GetOracleVersion(void);
int StartWinsock(void);
struct hostent *he;
struct sockaddr_in s_sa;
int ListenerPort=1521;
char host[260]="";
unsigned char TNSPacket[200]=
"\x00\x46\x00\x00\x01\x00\x00\x00\x01\x37\x01\x2C\x00\x00\x08\x00"
"\x7F\xFF\x86\x0E\x00\x00\x01\x00\x00\x0C\x00\x3A\x00\x00\x07\xF8"
"\x0C\x0C\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x0A\x4C\x00\x00"
"\x00\x03\x00\x00\x00\x00\x00\x00\x00\x00";

int main(int argc, char *argv[])
{
	unsigned int err=0;
	if(argc == 1)
	{
		printf("\n\t*** OraVer ***");
		printf("\n\n\tGets the Oracle version number.");
		printf("\n\n\tC:\\>%s host [port]",argv[0]);
		printf("\n\n\tDavid Litch-field\n\tdavidl@ngssoftware.com\n\t22th April 2003\n");
		return 0;
	}
	strncpy(host,argv[1],256);
	if(argc == 3)
		ListenerPort = atoi(argv[2]);
	err = StartWinsock();
	if(err==0)
		printf("Error starting Winsock.\n");
	else
		GetOracleVersion();
	WSACleanup();
	return 0;
}		

int StartWinsock()
{
	int err=0;
	unsigned int addr;
	WORD wVersionRequested;
	WSADATA wsaData;
	wVersionRequested = MAKEWORD( 2, 0 );
	err = WSAStartup( wVersionRequested, &wsaData );
	if ( err != 0 )
		return 0;
	
	if ( LOBYTE( wsaData.wVersion ) != 2 || HIBYTE( wsaData.wVersion ) != 0 )
		return 0;
	
	s_sa.sin_addr.s_addr=INADDR_ANY;
	s_sa.sin_family=AF_INET;
	if (isalpha(host[0]))
	{
  		he = gethostbyname(host);
		if(he == NULL)
		{
			printf("Failed to look up %s\n",host);
			return 0;
		}
		memcpy(&s_sa.sin_addr,he->h_addr,he->h_length);
	}
	else
	{
		addr = inet_addr(host);
		memcpy(&s_sa.sin_addr,&addr,4);
	}
	return 1;
}

int GetOracleVersion(void)
{
	
	unsigned char resp[200]="";
	unsigned char ver[8]="";
	unsigned char h=0,l=0,p=0,q=0;
	int snd=0,rcv=0,count=0;
	SOCKET cli_sock;
	char *ptr = NULL;

	cli_sock=socket(AF_INET,SOCK_STREAM,0);
	if (cli_sock==INVALID_SOCKET)
    		return printf("\nFailed to create the socket.\n");
	
	s_sa.sin_port=htons((unsigned short)ListenerPort);
	if (con-nect(cli_sock,(LPSOCKADDR)&s_sa,sizeof(s_sa))==SOCKET_ERROR)
	{
		printf("\nFailed to connect to the Listener.\n");
		goto The_End;
	}
	snd=send(cli_sock, TNSPacket , 0x3A , 0);
	snd=send(cli_sock, "NGSSoftware\x00" , 12 , 0);
	rcv = recv(cli_sock,resp,196,0);
	if(rcv == SOCKET_ERROR)
	{
		printf("\nThere was a receive error.\n");
		goto The_End;
	}
	while(count < rcv)
	{
		if(resp[count]==0x00)
			resp[count]=0x20;
		count++;
	}
	
	ptr = strstr(resp,"(VSNNUM=");
	if(!ptr)
	{
		printf("\nFailed to get the version.\n");
		goto The_End;
	}
	ptr = ptr + 8;
	count = atoi(ptr);
	count = count << 4;
	memmove(ver,&count,4);
	h = ver[3] >> 4;
	l = ver[3] << 4;
	l = l >> 4;
	p = ver[1] >> 4;
	q = ver[0] >> 4;
	printf("\nVersion of Oracle is %d.%d.%d.%d.%d\n",h,l,ver[2],p,q);
The_End:
	closesocket(cli_sock);
	return 0;
}
