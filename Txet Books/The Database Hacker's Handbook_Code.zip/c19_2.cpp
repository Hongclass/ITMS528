#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <io.h>
enum Item_result {STRING_RESULT, REAL_RESULT, INT_RESULT, ROW_RESULT};
typedef struct st_udf_args
{
unsigned int arg_count;      /* Number of arguments */
enum Item_result *arg_type;      /* Pointer to item_results */
char **args;            /* Pointer to argument */
unsigned long *lengths;      /* Length of string arguments */
char *maybe_null;            /* Set to 1 for maybe_null args */
} UDF_ARGS;
typedef struct st_udf_init
{
char maybe_null;             /* 1 if function can return NULL */
unsigned int decimals;      /* for real functions */
unsigned long max_length;        /* For string functions */
char        *ptr;        /* free pointer for function data */
char const_item;      /* 0 if result is independent of arguments */
} UDF_INIT;

extern "C" _declspec(dllexport) char *do_system(UDF_INIT *initid, UDF_ARGS *args,
char *result, unsigned long *length,
char *is_null, char *error)
{
      int bufsiz = 1024 * 8, retlen;
      char *buff = (char *)malloc( bufsiz );
      
      if( args->arg_count != 1 )
            return 0;
      system( args->args[0] );
      
      strcpy( buff, "Success" );
      retlen = (int)strlen( buff ) + 1;
      *length = retlen;
      initid->ptr = buff;
      
      return buff;
}
extern "C" _declspec(dllexport) void do_system_deinit(UDF_INIT *initid)
{
      if( initid->ptr )
            free( initid->ptr );
}
