create procedure proxy( @outhost varchar(1000), @outport integer, @inhost varchar(1000), @inport integer ) as
begin
      declare @sout java.net.Socket
      declare @sin java.net.Socket
      declare @outis java.io.InputStream
      declare @outos java.io.OutputStream
      declare @inis java.io.InputStream
      declare @inos java.io.OutputStream
      declare @buffer varchar(2000)
      declare @no_out integer
      declare @no_in integer
      declare @i integer
      set @sout = new java.net.Socket( @outhost, @outport )
      set @outis = @sout>>getInputStream()
      set @outos = @sout>>getOutputStream()
      set @sin = new java.net.Socket( @inhost, @inport )
      set @inis = @sin>>getInputStream()
      set @inos = @sin>>getOutputStream()
      set @i = 0
      while(@i < 60)
      begin
            if(@outis>>available() > 0)
            begin
                  set @buffer = char(@outis>>"read"())
                  while( @outis>>available() > 0 )
                  begin
                        set @buffer = @buffer + char(@outis>>"read"())
                  end
                  set @inos = @inos>>"write"(convert(varbinary(2000), @buffer))
                  set @no_out = 0
                  set @i = 0
            end
            else
                  set @no_out = 1
            if(@inis>>available() > 0)
            begin
                  set @buffer = char(@inis>>"read"())
                  while( @inis>>available() > 0 )
                  begin
                        set @buffer = @buffer + char(@inis>>"read"())
                  end
                  set @outos = @outos>>"write"(convert(varbinary(2000), @buffer))
                  set @no_in = 0
                  set @i = 0
            end
            else
                  set @no_in = 1
            if(( @no_in = 1 ) and ( @no_out = 1 ))
            begin
                  set @no_in = java.lang.Thread.currentThread()>>sleep( 1000 )      
                  set @i = @i + 1
            end
      end
      set @sout = @sout>>"close"()
      set @sin = @sin>>"close"()
end
